﻿namespace Ch_10_Exercise_10_1
{
    partial class List_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListViewTheater = new System.Windows.Forms.ListView();
            this.lblResult = new System.Windows.Forms.Label();
            this.HscrollTickets = new System.Windows.Forms.HScrollBar();
            this.btnCompute = new System.Windows.Forms.Button();
            this.lblPriceResults = new System.Windows.Forms.Label();
            this.lblSelectedCell = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ListViewTheater
            // 
            this.ListViewTheater.FullRowSelect = true;
            this.ListViewTheater.GridLines = true;
            this.ListViewTheater.HideSelection = false;
            this.ListViewTheater.Location = new System.Drawing.Point(12, 68);
            this.ListViewTheater.Name = "ListViewTheater";
            this.ListViewTheater.Size = new System.Drawing.Size(399, 200);
            this.ListViewTheater.TabIndex = 0;
            this.ListViewTheater.UseCompatibleStateImageBehavior = false;
            this.ListViewTheater.View = System.Windows.Forms.View.Details;
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(282, 32);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(16, 13);
            this.lblResult.TabIndex = 1;
            this.lblResult.Text = "...";
            // 
            // HscrollTickets
            // 
            this.HscrollTickets.LargeChange = 1;
            this.HscrollTickets.Location = new System.Drawing.Point(98, 18);
            this.HscrollTickets.Maximum = 10;
            this.HscrollTickets.Name = "HscrollTickets";
            this.HscrollTickets.Size = new System.Drawing.Size(160, 36);
            this.HscrollTickets.TabIndex = 2;
            // 
            // btnCompute
            // 
            this.btnCompute.Location = new System.Drawing.Point(15, 286);
            this.btnCompute.Name = "btnCompute";
            this.btnCompute.Size = new System.Drawing.Size(122, 47);
            this.btnCompute.TabIndex = 3;
            this.btnCompute.Text = "Compute";
            this.btnCompute.UseVisualStyleBackColor = true;
            // 
            // lblPriceResults
            // 
            this.lblPriceResults.AutoSize = true;
            this.lblPriceResults.Location = new System.Drawing.Point(239, 303);
            this.lblPriceResults.Name = "lblPriceResults";
            this.lblPriceResults.Size = new System.Drawing.Size(19, 13);
            this.lblPriceResults.TabIndex = 4;
            this.lblPriceResults.Text = "....";
            // 
            // lblSelectedCell
            // 
            this.lblSelectedCell.AutoSize = true;
            this.lblSelectedCell.Location = new System.Drawing.Point(239, 334);
            this.lblSelectedCell.Name = "lblSelectedCell";
            this.lblSelectedCell.Size = new System.Drawing.Size(16, 13);
            this.lblSelectedCell.TabIndex = 5;
            this.lblSelectedCell.Text = "...";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "# Of Tickets:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(167, 303);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Total Price:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(161, 334);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Selected Cell:";
            // 
            // List_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 372);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblSelectedCell);
            this.Controls.Add(this.lblPriceResults);
            this.Controls.Add(this.btnCompute);
            this.Controls.Add(this.HscrollTickets);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.ListViewTheater);
            this.Name = "List_View";
            this.Text = "List View";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView ListViewTheater;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.HScrollBar HscrollTickets;
        private System.Windows.Forms.Button btnCompute;
        private System.Windows.Forms.Label lblPriceResults;
        private System.Windows.Forms.Label lblSelectedCell;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}
