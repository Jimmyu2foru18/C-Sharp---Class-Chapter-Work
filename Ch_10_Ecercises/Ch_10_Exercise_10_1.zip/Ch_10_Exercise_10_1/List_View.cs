﻿using System;
using System.Windows.Forms;

namespace Ch_10_Exercise_10_1
{
    public partial class List_View : Form
    {
        public List_View()
        {
            InitializeComponent();

            ListViewTheater.Columns.Add("ShowId", 100);
            ListViewTheater.Columns.Add("Name of Show", 200);
            ListViewTheater.Columns.Add("Ticket Price", 100);

            AddListViewItems();
            HscrollTickets.Scroll += HscrollTickets_Scroll;
            btnCompute.Click += btnCompute_Click;
            ListViewTheater.SelectedIndexChanged += ListViewTheater_SelectedIndexChanged;
        }

        private void AddListViewItems()
        {
            string[][] data = new string[][] {
                new string[] { "101", "Mamma Mia", "75" },
                new string[] { "102", "Rock of Ages", "60" },
                new string[] { "103", "Les Miserables", "70" },
                new string[] { "104", "Motown The Musical", "65" },
                new string[] { "105", "The Lion King", "90" }
            };

            foreach (var item in data)
            {
                ListViewItem listViewItem = new ListViewItem(item);
                ListViewTheater.Items.Add(listViewItem);
            }
        }

        private void HscrollTickets_Scroll(object sender, ScrollEventArgs e)
        {
            lblResult.Text = HscrollTickets.Value.ToString();
        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            int numTickets = HscrollTickets.Value;
            int totalPrice = 0;

            if (ListViewTheater.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = ListViewTheater.SelectedItems[0];
                int ticketPrice = int.Parse(selectedItem.SubItems[2].Text);
                totalPrice = numTickets * ticketPrice;
            }

            lblPriceResults.Text = "Total Price: $" + totalPrice.ToString();
        }

        private void ListViewTheater_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListViewTheater.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = ListViewTheater.SelectedItems[0];
                lblSelectedCell.Text = selectedItem.SubItems[1].Text;
            }
            else
            {
                lblSelectedCell.Text = "";
            }
        }
    }
}
