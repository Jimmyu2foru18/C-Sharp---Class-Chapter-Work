﻿using System;
using System.Windows.Forms;

namespace Ch_10_Exercise_10_1
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new List_View()); // Replace List_View() with the name of your form
        }
    }
}
