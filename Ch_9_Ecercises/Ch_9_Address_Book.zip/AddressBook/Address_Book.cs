﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddressBook
{
    public partial class Address_Book : Form
    {
        public Address_Book()
        {
            InitializeComponent();
        }
        StreamReader read;
        StreamWriter write;
        string[] names;
        string[] states;


        private void Address_Book_Load(object sender, EventArgs e)
        {
            try
            {
                read = new StreamReader("Addresses.txt");
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
        private void btnListInfo_Click(object sender, EventArgs e)
        {
            names = new string[20];
            states = new string[20];
            string info;
            lstResults.Items.Clear();
            string[] fields;

            int index = 0;
            while ((info = read.ReadLine()) != null && index < 20)
            {
                fields = info.Split(',');
                lstResults.Items.Add(info);
                names[index] = fields[0];
                states[index] = fields[3];
                index++;
            }
        }

        private void Address_Book_FormClosed_1(object sender, FormClosedEventArgs e)
        {
            if (read != null)
                read.Close();
            if (write != null)
                write.Close();
        }

        private void btnFindAddress_Click(object sender, EventArgs e)
        {
            if (names == null || states == null)
            {
                MessageBox.Show("Please load data first!");
                return;
            }

            string search = txtName.Text;
            int index = Array.IndexOf(names, search);

            if (index == -1)
            {
                MessageBox.Show("Sorry, Not Found");
            }
            else
            {
                lstResults.Items.Add(string.Format("{0,-18 }{1,8}", search, states[index]));
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            {
                if (write == null)
                {
                    try
                    {
                        write = new StreamWriter("Addresses.txt", true);
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                        return;
                    }
                }
                string n = txtFullName.Text;
                string s = txtStreet.Text;
                string c = txtCity.Text;
                string st = txtState.Text;
                string z = txtZip.Text;

                write.WriteLine(n + " ," + s + " ," + c + " ," + st + " ," + z);
            }
        }
    }
}