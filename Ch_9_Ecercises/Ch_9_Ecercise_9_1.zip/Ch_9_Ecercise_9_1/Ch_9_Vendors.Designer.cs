﻿namespace Ch_9_Ecercise_9_1
{
    partial class Ch_9_Vendors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CboVendors = new System.Windows.Forms.ComboBox();
            this.lstVendors = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // CboVendors
            // 
            this.CboVendors.FormattingEnabled = true;
            this.CboVendors.Location = new System.Drawing.Point(12, 18);
            this.CboVendors.Name = "CboVendors";
            this.CboVendors.Size = new System.Drawing.Size(146, 21);
            this.CboVendors.TabIndex = 0;
            this.CboVendors.SelectedIndexChanged += new System.EventHandler(this.CboVendors_SelectedIndexChanged);
            // 
            // lstVendors
            // 
            this.lstVendors.FormattingEnabled = true;
            this.lstVendors.Location = new System.Drawing.Point(164, 18);
            this.lstVendors.Name = "lstVendors";
            this.lstVendors.Size = new System.Drawing.Size(300, 225);
            this.lstVendors.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 255);
            this.Controls.Add(this.lstVendors);
            this.Controls.Add(this.CboVendors);
            this.Name = "Form1";
            this.Text = "Vendors";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox CboVendors;
        private System.Windows.Forms.ListBox lstVendors;
    }
}

