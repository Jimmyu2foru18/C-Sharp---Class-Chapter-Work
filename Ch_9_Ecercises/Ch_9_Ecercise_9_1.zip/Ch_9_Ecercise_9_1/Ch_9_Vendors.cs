﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch_9_Ecercise_9_1
{
    public partial class Ch_9_Vendors : Form
    {
        List<string[]> vendors = new List<string[]>();

        public Ch_9_Vendors()
        {
            InitializeComponent();
            LoadVendorData();
            PopulateComboBox();
        }

        private void LoadVendorData()
        {
            StreamReader reader = new StreamReader("Vendor.txt");
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                string[] vendorInfo = line.Split(',');
                vendors.Add(vendorInfo);
            }
            reader.Close();
        }

        private void PopulateComboBox()
        {
            var vendorNames = vendors.Select(v => v[1]).OrderBy(n => n).ToList();
            CboVendors.Items.AddRange(vendorNames.ToArray());
        }


        private void CboVendors_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstVendors.Items.Clear();
            string selectedVendorName = CboVendors.SelectedItem.ToString();
            string[] selectedVendor = vendors.Find(v => v[1] == selectedVendorName);

            if (selectedVendor != null)
            {
                lstVendors.Items.Add($"Name: {selectedVendor[1]}");
                lstVendors.Items.Add($"Zip Code: {selectedVendor[5]}");
                lstVendors.Items.Add($"Phone Number: {selectedVendor[6]}");
            }
        }
    }
}