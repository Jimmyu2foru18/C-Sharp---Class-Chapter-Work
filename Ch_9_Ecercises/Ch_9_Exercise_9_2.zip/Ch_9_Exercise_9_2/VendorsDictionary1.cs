﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace Ch_9_Exercise_9_2
{
    public partial class VendorsDictionary1 : Form
    {
        private Dictionary<string, string> vendorPhones = new Dictionary<string, string>();



        public VendorsDictionary1()
        {
            InitializeComponent();
            LoadVendorData();
            PopulateComboBox();
        }



        private void LoadVendorData()
        {
            StreamReader reader = new StreamReader("Vendor.txt");
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                string[] data = line.Split(',');
                string vendorName = data[1];
                string phoneNumber = data[6];
                vendorPhones.Add(vendorName, phoneNumber);
            }
            reader.Close();
        }



        private void PopulateComboBox()
        {
            var vendorNames = vendorPhones.Keys.OrderBy(n => n).ToList();
            cboVendor.Items.AddRange(vendorNames.ToArray());
        }




        private void cboVendor_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstVendor.Items.Clear();
            string selectedVendorName = cboVendor.SelectedItem.ToString();
            string phoneNumber = vendorPhones[selectedVendorName];
            lstVendor.Items.Add($"Name: {selectedVendorName}");
            lstVendor.Items.Add($"Phone Number: {phoneNumber}");
        }
    }
}
