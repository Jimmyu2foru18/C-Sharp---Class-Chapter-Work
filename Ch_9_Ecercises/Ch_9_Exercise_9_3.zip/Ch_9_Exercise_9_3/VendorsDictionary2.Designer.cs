﻿namespace Ch_9_Exercise_3
{
    partial class VendorsDictionary2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboVendor = new System.Windows.Forms.ComboBox();
            this.lst = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // cboVendor
            // 
            this.cboVendor.FormattingEnabled = true;
            this.cboVendor.Location = new System.Drawing.Point(7, 21);
            this.cboVendor.Name = "cboVendor";
            this.cboVendor.Size = new System.Drawing.Size(159, 21);
            this.cboVendor.TabIndex = 0;
            this.cboVendor.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lst
            // 
            this.lst.FormattingEnabled = true;
            this.lst.Location = new System.Drawing.Point(172, 21);
            this.lst.Name = "lst";
            this.lst.Size = new System.Drawing.Size(311, 251);
            this.lst.TabIndex = 1;
            // 
            // VendorsDictionary2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(499, 288);
            this.Controls.Add(this.lst);
            this.Controls.Add(this.cboVendor);
            this.Name = "VendorsDictionary2";
            this.Text = "Vendor Dictionary";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cboVendor;
        private System.Windows.Forms.ListBox lst;
    }
}

