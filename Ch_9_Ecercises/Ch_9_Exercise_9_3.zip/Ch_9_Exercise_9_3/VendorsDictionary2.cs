﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Ch_9_Exercise_3
{
    public partial class VendorsDictionary2 : Form
    {
        private Dictionary<string, string[]> vendors = new Dictionary<string, string[]>();
        public VendorsDictionary2()
        {
            InitializeComponent();
            LoadVendorData();
            PopulateComboBox();
        }
            private void LoadVendorData()
            {
                StreamReader reader = new StreamReader("Vendor.txt");
                try
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] data = line.Split(',');
                        string vendorName = data[1];
                        string zipCode = data[4];
                        string phoneNumber = data[6];
                        string[] zipPhoneArray = { zipCode, phoneNumber };
                        vendors.Add(vendorName, zipPhoneArray);
                    }
                }
                finally
                {
                    if (reader != null)
                    {
                        reader.Close();
                    }
                }
            }

            private void PopulateComboBox()
            {
                var sortedVendors = vendors.Keys.ToList();
                sortedVendors.Sort();
                cboVendor.DataSource = sortedVendors;
            }

            private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
            {
                string selectedVendor = cboVendor.SelectedItem.ToString();
                string[] zipPhoneArray = vendors[selectedVendor];
                lst.Items.Clear();
                lst.Items.Add(selectedVendor + ": Zip Code - " + zipPhoneArray[0] + ", Phone Number - " + zipPhoneArray[1]);
            }
        }
    }